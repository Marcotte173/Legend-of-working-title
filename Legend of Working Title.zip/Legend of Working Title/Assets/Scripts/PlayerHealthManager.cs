﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealthManager : MonoBehaviour
{
    public int maxHealth;
    public int health;
    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if(health <= 0)
        {
            gameObject.SetActive(false);
        }        
    }
    public void DamagePlayer(int damage) { health -= damage;}
    public void SetMaxHealth() { health = maxHealth; }

}
